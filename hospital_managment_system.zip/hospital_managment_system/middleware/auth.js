// middleware/auth.js

export function requireLogin(req, res, next) {
    if (!req.session.userId) return res.redirect('/login');
    next();
}

export function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.session.userId) return res.redirect('/login');
        if (!roles.includes(req.session.role)) {
            return res.status(403).render('error', { message: 'Access Denied: Insufficient permissions.' });
        }
        next();
    };
}
