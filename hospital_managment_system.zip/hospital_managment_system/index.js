import express from 'express';
import session from 'express-session';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

import authRoutes    from './routes/auth.js';
import adminRoutes   from './routes/admin.js';
import doctorRoutes  from './routes/doctor.js';
import nurseRoutes   from './routes/nurse.js';
import patientRoutes from './routes/patient.js';

dotenv.config();

const app  = express();
const PORT = process.env.PORT || 8000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── View Engine ────────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ── Middleware ─────────────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
    secret: process.env.SESSION_SECRET || 'hms_secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24h
}));

// ── Routes ─────────────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
    if (req.session.userId) return res.redirect(`/${req.session.role}/dashboard`);
    res.render('index');
});

app.use('/',        authRoutes);
app.use('/admin',   adminRoutes);
app.use('/doctor',  doctorRoutes);
app.use('/nurse',   nurseRoutes);
app.use('/patient', patientRoutes);

// ── 404 & Error ────────────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).render('error', { message: 'Page not found.' }));
app.use((err, req, res, next) => {
    console.error('❌ ERROR:', err.message);
    console.error(err.stack);
    res.status(500).render('error', { message: err.message || 'Internal server error.' });
});

app.listen(PORT, () => console.log(`🏥 Hospital Management System running on http://localhost:${PORT}`));
