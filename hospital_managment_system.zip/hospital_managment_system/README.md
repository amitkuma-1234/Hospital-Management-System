# 🏥 MediCare HMS — Hospital Management System v2.0

A clean, modern, **production-ready** Hospital Management System built with **Node.js**, **Express**, **EJS**, and **MySQL**.
Suitable for resume projects, internship demos, and real-world simulation.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| **Unified Auth** | Single `users` table with bcrypt-hashed passwords |
| **Role-Based Access** | Admin, Doctor, Nurse, Patient — each with dedicated dashboard |
| **Appointment System** | Booking, status tracking (Scheduled/Completed/Cancelled), double-booking prevention |
| **Medical Records** | Diagnosis, treatment, lab results — linked to doctor & patient |
| **Prescriptions** | Written by doctors after completed appointments, viewable by patients |
| **Billing** | Generate bills, track payment status (Pending/Paid), linked to patients |
| **Nurse Assignments** | Assign nurses to patients with care notes |
| **Patient Self-Service** | Register, book appointments, view records, pay bills, manage profile |
| **Modern UI** | Clean sidebar layout, responsive design, no external CSS frameworks |
| **Security** | bcrypt passwords, session auth, role guards, parameterized SQL queries |

---

## 🚀 Setup Instructions

### 1. Prerequisites
- **Node.js** v18+
- **MySQL** 8.0+

### 2. Database Setup

Open your MySQL client and run:
```sql
source hospital_managment_system_sql.sql
```
Or import the file via **MySQL Workbench** / **phpMyAdmin**.

> This creates the `hospital_management` database, all tables, and inserts sample data.

### 3. Configure Environment

Edit the `.env` file with your MySQL credentials:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=hospital_management
SESSION_SECRET=any_random_secret_string
PORT=8000
```

### 4. Install Dependencies
```bash
npm install
```

### 5. Clean Up (One-time)
```bash
node cleanup.js
```
Then delete `cleanup.js`.

### 6. Run the App
```bash
npm start
# or for development with auto-reload:
npm run dev
```

### 7. Open in Browser
```
http://localhost:8000
```

---

## 🔑 Demo Login Credentials

All demo users have password: **`password123`**

| Role    | Username      | Full Name         |
|---------|---------------|--------------------|
| Admin   | `admin01`     | Admin User         |
| Doctor  | `dr.sharma`   | Dr. Anil Sharma    |
| Doctor  | `dr.mehta`    | Dr. Neha Mehta     |
| Nurse   | `nur.priya`   | Nurse Priya Patel  |
| Patient | `rahul.singh` | Rahul Singh        |
| Patient | `sunita.rao`  | Sunita Rao         |

---

## 👥 Role Capabilities

### 🧑‍💼 Admin
- View system-wide dashboard with stats (doctors, nurses, patients, appointments, billing)
- Manage users (create/update/delete all roles)
- Manage departments (add/edit/delete)
- Manage appointments (schedule, update status)
- Manage billing (create bills, update payment status, delete)
- Manage nurse-patient assignments

### 👨‍⚕️ Doctor
- View personal dashboard (today's appointments, total patients, pending)
- View and manage appointments (update status)
- Create and edit medical records (diagnosis, treatment, lab results)
- Write prescriptions linked to completed appointments

### 🩺 Nurse
- View dashboard with assigned patients and today's appointments
- View assigned patients with health info
- Update care notes for assigned patients
- View all appointments (read-only)
- View medical records (read-only)

### 🛌 Patient
- Register and login
- View personal dashboard (upcoming appointments, pending bills)
- Book appointments with doctors (with double-booking prevention)
- Cancel scheduled appointments
- View prescriptions and medical records
- View and pay pending bills
- Update personal profile (age, gender, phone, blood group, address)

---

## 📁 Project Structure

```
hospital-management-system/
├── index.js                          # App entry point
├── db.js                             # MySQL pool connection
├── .env                              # Environment config
├── hospital_managment_system_sql.sql # Full database schema + sample data
├── package.json
│
├── middleware/
│   └── auth.js             # requireLogin, requireRole guards
│
├── routes/
│   ├── auth.js             # Login, signup, logout
│   ├── admin.js            # Admin CRUD routes
│   ├── doctor.js           # Doctor routes
│   ├── nurse.js            # Nurse routes
│   └── patient.js          # Patient routes
│
├── views/
│   ├── index.ejs           # Landing page
│   ├── login.ejs           # Login
│   ├── signup.ejs          # Patient registration
│   ├── error.ejs           # Error page
│   ├── partials/
│   │   ├── layout_top.ejs  # Sidebar + topbar (shared)
│   │   └── layout_bottom.ejs # Closing tags + JS (shared)
│   ├── admin/
│   │   ├── dashboard.ejs
│   │   ├── users.ejs
│   │   ├── departments.ejs
│   │   ├── appointments.ejs
│   │   ├── billing.ejs
│   │   └── nurse_assignments.ejs
│   ├── doctor/
│   │   ├── dashboard.ejs
│   │   ├── appointments.ejs
│   │   ├── medical_records.ejs
│   │   └── prescriptions.ejs
│   ├── nurse/
│   │   ├── dashboard.ejs
│   │   ├── patients.ejs
│   │   ├── appointments.ejs
│   │   └── medical_records.ejs
│   └── patient/
│       ├── dashboard.ejs
│       ├── appointments.ejs
│       ├── prescriptions.ejs
│       ├── medical_records.ejs
│       ├── billing.ejs
│       └── profile.ejs
│
└── public/
    └── stylesheets/
        └── style.css       # Full custom CSS (no framework)
```

---

## 🗄️ Database Schema

| Table | Purpose |
|-------|---------|
| `users` | Unified authentication (username, password, role) |
| `department` | Hospital departments |
| `doctor` | Doctor profiles (linked to users + department) |
| `nurse` | Nurse profiles (linked to users + department) |
| `patient` | Patient profiles (linked to users) |
| `appointment` | Appointment scheduling (doctor ↔ patient) |
| `medical_record` | Diagnosis, treatment, lab results |
| `prescription` | Medications linked to appointments |
| `billing` | Bill generation and payment tracking |
| `nurse_assignment` | Nurse-patient assignments with care notes |

All tables use proper **foreign key relationships** with `ON DELETE CASCADE` / `ON DELETE SET NULL`.

---

## 🔐 Security Features

- Passwords hashed with **bcrypt** (10 salt rounds)
- **Session-based auth** with 24-hour expiry
- **Role guards** on every protected route
- **Parameterized SQL queries** (no SQL injection)
- Input validation on forms (frontend + backend)
- Double-booking prevention for appointments
- Users cannot delete their own admin account

---

## 🛠 Tech Stack

| Layer     | Technology                |
|-----------|---------------------------|
| Runtime   | Node.js (ESM modules)     |
| Framework | Express.js                |
| Views     | EJS templates             |
| Database  | MySQL 8 via mysql2        |
| Auth      | express-session + bcryptjs |
| Styling   | Custom CSS (Inter font, no framework) |

---

## 📝 Notes

- **No AI/ML features** — clean, simple, professional system
- All routes are fully functional and tested
- Responsive design works on mobile and desktop
- Frontend uses emoji icons — no external icon libraries needed
