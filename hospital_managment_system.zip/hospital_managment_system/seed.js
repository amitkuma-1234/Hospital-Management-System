// seed.js — Reset all demo user passwords to 'password123' with correct bcrypt hashes
// Run: node seed.js

import bcrypt from 'bcryptjs';
import db from './db.js';

async function seed() {
    try {
        const password = 'password123';
        const hash = await bcrypt.hash(password, 10);
        console.log('Generated hash for "password123":', hash);

        // Update all demo users with the correct hash
        const [result] = await db.query('UPDATE users SET password = ?', [hash]);
        console.log(`✅ Updated ${result.affectedRows} users with correct password hash.`);
        console.log('All users can now login with password: password123');

        // Show all users
        const [users] = await db.query('SELECT user_id, username, full_name, role FROM users');
        console.log('\n📋 Current users:');
        users.forEach(u => console.log(`   ${u.role.padEnd(8)} | ${u.username.padEnd(14)} | ${u.full_name}`));

        process.exit(0);
    } catch (err) {
        console.error('❌ Error:', err.message);
        process.exit(1);
    }
}

seed();
