// cleanup.js — Run once: node cleanup.js
const fs = require('fs');
const path = require('path');

function removeDirRecursive(dirPath) {
  if (!fs.existsSync(dirPath)) return;
  fs.readdirSync(dirPath).forEach(file => {
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isDirectory()) {
      removeDirRecursive(fullPath);
    } else {
      fs.unlinkSync(fullPath);
    }
  });
  fs.rmdirSync(dirPath);
  console.log('Removed:', dirPath);
}

// Remove stale directories with curly-brace names (artifacts from bad zip extraction)
const stale = [
  path.join(__dirname, '{views,public'),
  path.join(__dirname, 'views', '{partials,admin,doctor,nurse,patient}'),
];

stale.forEach(p => {
  try { removeDirRecursive(p); } 
  catch(e) { console.log('Skipped:', p, '-', e.message); }
});

console.log('✅ Cleanup complete!');
