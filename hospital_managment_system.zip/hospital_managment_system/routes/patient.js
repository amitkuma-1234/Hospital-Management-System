// routes/patient.js
import express from 'express';
import db from '../db.js';
import { requireRole } from '../middleware/auth.js';

const router = express.Router();
router.use(requireRole('patient'));

async function getPatientId(userId) {
    const [[p]] = await db.query('SELECT patient_id FROM patient WHERE user_id=?', [userId]);
    return p?.patient_id;
}

router.get('/dashboard', async (req, res) => {
    try {
        const patId = await getPatientId(req.session.userId);
        const [[{ upcomingAppts }]] = await db.query(
            "SELECT COUNT(*) AS upcomingAppts FROM appointment WHERE patient_id=? AND status='Scheduled' AND appointment_time>=NOW()", [patId]);
        const [[{ pendingBills }]] = await db.query(
            "SELECT COUNT(*) AS pendingBills FROM billing WHERE patient_id=? AND payment_status='Pending'", [patId]);
        const [upcoming] = await db.query(`
            SELECT a.*, u.full_name AS doctor_name, d.specializations
            FROM appointment a
            JOIN doctor d ON a.doctor_id=d.doctor_id
            JOIN users u ON d.user_id=u.user_id
            WHERE a.patient_id=? AND a.status='Scheduled' AND a.appointment_time>=NOW()
            ORDER BY a.appointment_time ASC LIMIT 3`, [patId]);
        res.render('patient/dashboard', { session: req.session, stats: { upcomingAppts, pendingBills }, upcoming });
    } catch (err) {
        res.render('error', { message: 'Error loading dashboard.' });
    }
});

router.get('/appointments', async (req, res) => {
    try {
        const patId = await getPatientId(req.session.userId);
        const [appointments] = await db.query(`
            SELECT a.*, u.full_name AS doctor_name, d.specializations
            FROM appointment a
            JOIN doctor d ON a.doctor_id=d.doctor_id
            JOIN users u ON d.user_id=u.user_id
            WHERE a.patient_id=? ORDER BY a.appointment_time DESC`, [patId]);
        const [doctors] = await db.query('SELECT d.doctor_id, u.full_name, d.specializations FROM doctor d JOIN users u ON d.user_id=u.user_id');
        res.render('patient/appointments', { session: req.session, appointments, doctors, error: req.query.error, success: req.query.success });
    } catch (err) {
        res.render('error', { message: 'Error loading appointments.' });
    }
});

router.post('/appointments/book', async (req, res) => {
    const { doctor_id, appointment_time, reason } = req.body;
    try {
        const patId = await getPatientId(req.session.userId);
        // Check double booking
        const [conflict] = await db.query(
            "SELECT 1 FROM appointment WHERE doctor_id=? AND appointment_time=? AND status!='Cancelled'",
            [doctor_id, appointment_time]);
        if (conflict.length) return res.redirect('/patient/appointments?error=That time slot is already booked. Please choose another.');
        await db.query(
            'INSERT INTO appointment (doctor_id, patient_id, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?)',
            [doctor_id, patId, appointment_time, reason, 'Scheduled']);
        res.redirect('/patient/appointments?success=Appointment booked successfully');
    } catch (err) {
        res.redirect('/patient/appointments?error=Booking failed');
    }
});

router.post('/appointments/cancel/:id', async (req, res) => {
    const patId = await getPatientId(req.session.userId);
    try {
        await db.query("UPDATE appointment SET status='Cancelled' WHERE appointment_id=? AND patient_id=?", [req.params.id, patId]);
        res.redirect('/patient/appointments?success=Appointment cancelled');
    } catch (err) {
        res.redirect('/patient/appointments?error=Cancel failed');
    }
});

router.get('/prescriptions', async (req, res) => {
    try {
        const patId = await getPatientId(req.session.userId);
        const [prescriptions] = await db.query(`
            SELECT pr.*, u.full_name AS doctor_name
            FROM prescription pr
            JOIN doctor d ON pr.doctor_id=d.doctor_id
            JOIN users u ON d.user_id=u.user_id
            WHERE pr.patient_id=? ORDER BY pr.prescription_date DESC`, [patId]);
        res.render('patient/prescriptions', { session: req.session, prescriptions });
    } catch (err) {
        res.render('error', { message: 'Error loading prescriptions.' });
    }
});

router.get('/medical-records', async (req, res) => {
    try {
        const patId = await getPatientId(req.session.userId);
        const [records] = await db.query(`
            SELECT mr.*, u.full_name AS doctor_name
            FROM medical_record mr
            JOIN doctor d ON mr.doctor_id=d.doctor_id
            JOIN users u ON d.user_id=u.user_id
            WHERE mr.patient_id=? ORDER BY mr.date_created DESC`, [patId]);
        res.render('patient/medical_records', { session: req.session, records });
    } catch (err) {
        res.render('error', { message: 'Error loading records.' });
    }
});

router.get('/billing', async (req, res) => {
    try {
        const patId = await getPatientId(req.session.userId);
        const [bills] = await db.query('SELECT * FROM billing WHERE patient_id=? ORDER BY bill_date DESC', [patId]);
        res.render('patient/billing', { session: req.session, bills, error: req.query.error || null, success: req.query.success || null });
    } catch (err) {
        res.render('error', { message: 'Error loading billing.' });
    }
});

router.post('/billing/pay/:id', async (req, res) => {
    const patId = await getPatientId(req.session.userId);
    try {
        await db.query("UPDATE billing SET payment_status='Paid' WHERE bill_id=? AND patient_id=?", [req.params.id, patId]);
        res.redirect('/patient/billing?success=Payment recorded successfully');
    } catch (err) {
        res.redirect('/patient/billing?error=Payment failed');
    }
});

router.get('/profile', async (req, res) => {
    try {
        const [[user]] = await db.query('SELECT * FROM users WHERE user_id=?', [req.session.userId]);
        const [[profile]] = await db.query('SELECT * FROM patient WHERE user_id=?', [req.session.userId]);
        res.render('patient/profile', { session: req.session, user, profile, error: req.query.error, success: req.query.success });
    } catch (err) {
        res.render('error', { message: 'Error loading profile.' });
    }
});

router.post('/profile/update', async (req, res) => {
    const { full_name, email, age, gender, phone_no, address, blood_group } = req.body;
    try {
        await db.query('UPDATE users SET full_name=?, email=? WHERE user_id=?', [full_name, email, req.session.userId]);
        const patId = await getPatientId(req.session.userId);
        await db.query('UPDATE patient SET age=?, gender=?, phone_no=?, address=?, blood_group=? WHERE patient_id=?',
            [age, gender, phone_no, address, blood_group, patId]);
        req.session.fullName = full_name;
        res.redirect('/patient/profile?success=Profile updated successfully');
    } catch (err) {
        res.redirect('/patient/profile?error=Update failed');
    }
});

export default router;
