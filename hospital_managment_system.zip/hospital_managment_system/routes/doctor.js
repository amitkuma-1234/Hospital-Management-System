// routes/doctor.js
import express from 'express';
import db from '../db.js';
import { requireRole } from '../middleware/auth.js';

const router = express.Router();
router.use(requireRole('doctor'));

async function getDoctorId(userId) {
    const [[doc]] = await db.query('SELECT doctor_id FROM doctor WHERE user_id=?', [userId]);
    return doc?.doctor_id;
}

// Dashboard
router.get('/dashboard', async (req, res) => {
    try {
        const docId = await getDoctorId(req.session.userId);
        const [[{ todayAppts }]] = await db.query(
            "SELECT COUNT(*) AS todayAppts FROM appointment WHERE doctor_id=? AND DATE(appointment_time)=CURDATE()", [docId]);
        const [[{ totalPatients }]] = await db.query(
            "SELECT COUNT(DISTINCT patient_id) AS totalPatients FROM appointment WHERE doctor_id=?", [docId]);
        const [[{ pendingAppts }]] = await db.query(
            "SELECT COUNT(*) AS pendingAppts FROM appointment WHERE doctor_id=? AND status='Scheduled'", [docId]);
        const [upcoming] = await db.query(`
            SELECT a.*, u.full_name AS patient_name
            FROM appointment a
            JOIN patient p ON a.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE a.doctor_id=? AND a.status='Scheduled' AND a.appointment_time >= NOW()
            ORDER BY a.appointment_time ASC LIMIT 5`, [docId]);
        res.render('doctor/dashboard', {
            session: req.session,
            stats: { todayAppts, totalPatients, pendingAppts },
            upcoming
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error loading dashboard.' });
    }
});

// Appointments
router.get('/appointments', async (req, res) => {
    try {
        const docId = await getDoctorId(req.session.userId);
        const [appointments] = await db.query(`
            SELECT a.*, u.full_name AS patient_name
            FROM appointment a
            JOIN patient p ON a.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE a.doctor_id=?
            ORDER BY a.appointment_time DESC`, [docId]);
        res.render('doctor/appointments', { session: req.session, appointments, error: req.query.error, success: req.query.success });
    } catch (err) {
        res.render('error', { message: 'Error loading appointments.' });
    }
});

router.post('/appointments/update/:id', async (req, res) => {
    const { status } = req.body;
    try {
        await db.query('UPDATE appointment SET status=? WHERE appointment_id=?', [status, req.params.id]);
        res.redirect('/doctor/appointments?success=Status updated');
    } catch (err) {
        res.redirect('/doctor/appointments?error=Update failed');
    }
});

// Medical Records
router.get('/medical-records', async (req, res) => {
    try {
        const docId = await getDoctorId(req.session.userId);
        const [records] = await db.query(`
            SELECT mr.*, u.full_name AS patient_name
            FROM medical_record mr
            JOIN patient p ON mr.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE mr.doctor_id=?
            ORDER BY mr.date_created DESC`, [docId]);
        const [patients] = await db.query(`
            SELECT DISTINCT p.patient_id, u.full_name
            FROM appointment a
            JOIN patient p ON a.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE a.doctor_id=?`, [docId]);
        res.render('doctor/medical_records', { session: req.session, records, patients, error: req.query.error, success: req.query.success });
    } catch (err) {
        res.render('error', { message: 'Error loading records.' });
    }
});

router.post('/medical-records/add', async (req, res) => {
    const { patient_id, diagnoses, treatments, lab_results } = req.body;
    try {
        const docId = await getDoctorId(req.session.userId);
        await db.query(
            'INSERT INTO medical_record (patient_id, doctor_id, date_created, diagnoses, treatments, lab_results) VALUES (?, ?, CURDATE(), ?, ?, ?)',
            [patient_id, docId, diagnoses, treatments, lab_results]);
        res.redirect('/doctor/medical-records?success=Record added');
    } catch (err) {
        res.redirect('/doctor/medical-records?error=Failed to add record');
    }
});

router.post('/medical-records/update/:id', async (req, res) => {
    const { diagnoses, treatments, lab_results } = req.body;
    try {
        await db.query('UPDATE medical_record SET diagnoses=?, treatments=?, lab_results=? WHERE record_id=?',
            [diagnoses, treatments, lab_results, req.params.id]);
        res.redirect('/doctor/medical-records?success=Record updated');
    } catch (err) {
        res.redirect('/doctor/medical-records?error=Update failed');
    }
});

// Prescriptions
router.get('/prescriptions', async (req, res) => {
    try {
        const docId = await getDoctorId(req.session.userId);
        const [prescriptions] = await db.query(`
            SELECT pr.*, u.full_name AS patient_name, a.appointment_time
            FROM prescription pr
            JOIN patient p ON pr.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            JOIN appointment a ON pr.appointment_id=a.appointment_id
            WHERE pr.doctor_id=?
            ORDER BY pr.prescription_date DESC`, [docId]);
        const [appointments] = await db.query(`
            SELECT a.appointment_id, u.full_name AS patient_name, a.appointment_time
            FROM appointment a
            JOIN patient p ON a.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE a.doctor_id=? AND a.status='Completed'`, [docId]);
        res.render('doctor/prescriptions', { session: req.session, prescriptions, appointments, error: req.query.error, success: req.query.success });
    } catch (err) {
        res.render('error', { message: 'Error loading prescriptions.' });
    }
});

router.post('/prescriptions/add', async (req, res) => {
    const { appointment_id, medication, dosage, instructions } = req.body;
    try {
        const docId = await getDoctorId(req.session.userId);
        const [[appt]] = await db.query('SELECT patient_id FROM appointment WHERE appointment_id=?', [appointment_id]);
        await db.query(
            'INSERT INTO prescription (appointment_id, doctor_id, patient_id, prescription_date, medication, dosage, instructions) VALUES (?, ?, ?, CURDATE(), ?, ?, ?)',
            [appointment_id, docId, appt.patient_id, medication, dosage, instructions]);
        res.redirect('/doctor/prescriptions?success=Prescription added');
    } catch (err) {
        res.redirect('/doctor/prescriptions?error=Failed to add prescription');
    }
});

export default router;
