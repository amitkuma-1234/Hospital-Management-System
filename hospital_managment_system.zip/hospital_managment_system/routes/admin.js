// routes/admin.js
import express from 'express';
import bcrypt from 'bcryptjs';
import db from '../db.js';
import { requireRole } from '../middleware/auth.js';

const router = express.Router();
router.use(requireRole('admin'));

// Dashboard
router.get('/dashboard', async (req, res) => {
    try {
        const [[{ totalDoctors }]]   = await db.query('SELECT COUNT(*) AS totalDoctors FROM doctor');
        const [[{ totalNurses }]]    = await db.query('SELECT COUNT(*) AS totalNurses FROM nurse');
        const [[{ totalPatients }]]  = await db.query('SELECT COUNT(*) AS totalPatients FROM patient');
        const [[{ totalAppointments }]] = await db.query('SELECT COUNT(*) AS totalAppointments FROM appointment');
        const [[{ pendingBills }]]   = await db.query("SELECT COUNT(*) AS pendingBills FROM billing WHERE payment_status='Pending'");
        const [[{ totalRevenue }]]   = await db.query("SELECT COALESCE(SUM(total_amount),0) AS totalRevenue FROM billing WHERE payment_status='Paid'");
        const [recentAppointments]   = await db.query(`
            SELECT a.*, u_d.full_name AS doctor_name, u_p.full_name AS patient_name
            FROM appointment a
            JOIN doctor d ON a.doctor_id = d.doctor_id
            JOIN users u_d ON d.user_id = u_d.user_id
            JOIN patient p ON a.patient_id = p.patient_id
            JOIN users u_p ON p.user_id = u_p.user_id
            ORDER BY a.created_at DESC LIMIT 5`);
        res.render('admin/dashboard', {
            session: req.session,
            stats: { totalDoctors, totalNurses, totalPatients, totalAppointments, pendingBills, totalRevenue },
            recentAppointments
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error loading dashboard.' });
    }
});

// ── Users ──────────────────────────────────────────────────────────────────────
router.get('/users', async (req, res) => {
    try {
        const [users] = await db.query('SELECT user_id, username, full_name, email, role, created_at FROM users ORDER BY role, full_name');
        res.render('admin/users', {
            session: req.session,
            users,
            error: req.query.error || null,
            success: req.query.success || null
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error fetching users.' });
    }
});

router.post('/users/add', async (req, res) => {
    const { username, full_name, email, password, role } = req.body;
    if (!username || !full_name || !password || !role) {
        return res.redirect('/admin/users?error=All required fields must be filled');
    }
    if (password.length < 6) {
        return res.redirect('/admin/users?error=Password must be at least 6 characters');
    }
    try {
        const hashed = await bcrypt.hash(password, 10);
        const [result] = await db.query(
            'INSERT INTO users (username, full_name, email, password, role) VALUES (?, ?, ?, ?, ?)',
            [username, full_name, email || null, hashed, role]
        );
        if (role === 'doctor')  await db.query('INSERT INTO doctor (user_id) VALUES (?)', [result.insertId]);
        if (role === 'nurse')   await db.query('INSERT INTO nurse (user_id) VALUES (?)',  [result.insertId]);
        if (role === 'patient') await db.query('INSERT INTO patient (user_id) VALUES (?)',[result.insertId]);
        res.redirect('/admin/users?success=User added successfully');
    } catch (err) {
        console.error(err);
        if (err.code === 'ER_DUP_ENTRY') {
            return res.redirect('/admin/users?error=Username or email already exists');
        }
        res.redirect('/admin/users?error=Failed to add user');
    }
});

router.post('/users/update/:id', async (req, res) => {
    const { full_name, email, password } = req.body;
    if (!full_name) {
        return res.redirect('/admin/users?error=Full name is required');
    }
    try {
        if (password && password.length >= 6) {
            const hashed = await bcrypt.hash(password, 10);
            await db.query('UPDATE users SET full_name=?, email=?, password=? WHERE user_id=?', [full_name, email || null, hashed, req.params.id]);
        } else {
            await db.query('UPDATE users SET full_name=?, email=? WHERE user_id=?', [full_name, email || null, req.params.id]);
        }
        res.redirect('/admin/users?success=User updated successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/users?error=Update failed');
    }
});

router.post('/users/delete/:id', async (req, res) => {
    if (parseInt(req.params.id) === req.session.userId) {
        return res.redirect('/admin/users?error=Cannot delete your own account');
    }
    try {
        await db.query('DELETE FROM users WHERE user_id=?', [req.params.id]);
        res.redirect('/admin/users?success=User deleted successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/users?error=Delete failed');
    }
});

// ── Departments ────────────────────────────────────────────────────────────────
router.get('/departments', async (req, res) => {
    try {
        const [departments] = await db.query(`
            SELECT d.*, 
                (SELECT COUNT(*) FROM doctor WHERE department_id = d.department_id) AS doctor_count,
                (SELECT COUNT(*) FROM nurse WHERE department_id = d.department_id) AS nurse_count
            FROM department d ORDER BY d.department_name`);
        res.render('admin/departments', {
            session: req.session,
            departments,
            error: req.query.error || null,
            success: req.query.success || null
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error loading departments.' });
    }
});

router.post('/departments/add', async (req, res) => {
    const { department_name, description } = req.body;
    if (!department_name) {
        return res.redirect('/admin/departments?error=Department name is required');
    }
    try {
        await db.query('INSERT INTO department (department_name, description) VALUES (?, ?)', [department_name, description || null]);
        res.redirect('/admin/departments?success=Department added successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/departments?error=Failed to add department');
    }
});

router.post('/departments/update/:id', async (req, res) => {
    const { department_name, description } = req.body;
    if (!department_name) {
        return res.redirect('/admin/departments?error=Department name is required');
    }
    try {
        await db.query('UPDATE department SET department_name=?, description=? WHERE department_id=?', [department_name, description || null, req.params.id]);
        res.redirect('/admin/departments?success=Department updated successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/departments?error=Update failed');
    }
});

router.post('/departments/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM department WHERE department_id=?', [req.params.id]);
        res.redirect('/admin/departments?success=Department deleted successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/departments?error=Delete failed (department may have linked doctors/nurses)');
    }
});

// ── Appointments ───────────────────────────────────────────────────────────────
router.get('/appointments', async (req, res) => {
    try {
        const [appointments] = await db.query(`
            SELECT a.*, u_d.full_name AS doctor_name, u_p.full_name AS patient_name
            FROM appointment a
            JOIN doctor d ON a.doctor_id = d.doctor_id
            JOIN users u_d ON d.user_id = u_d.user_id
            JOIN patient p ON a.patient_id = p.patient_id
            JOIN users u_p ON p.user_id = u_p.user_id
            ORDER BY a.appointment_time DESC`);
        const [doctors]  = await db.query('SELECT d.doctor_id, u.full_name FROM doctor d JOIN users u ON d.user_id=u.user_id');
        const [patients] = await db.query('SELECT p.patient_id, u.full_name FROM patient p JOIN users u ON p.user_id=u.user_id');
        res.render('admin/appointments', {
            session: req.session,
            appointments, doctors, patients,
            error: req.query.error || null,
            success: req.query.success || null
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error loading appointments.' });
    }
});

router.post('/appointments/add', async (req, res) => {
    const { doctor_id, patient_id, appointment_time, reason } = req.body;
    if (!doctor_id || !patient_id || !appointment_time) {
        return res.redirect('/admin/appointments?error=Doctor, patient and time are required');
    }
    try {
        // Check for double booking
        const [conflict] = await db.query(
            "SELECT 1 FROM appointment WHERE doctor_id=? AND appointment_time=? AND status!='Cancelled'",
            [doctor_id, appointment_time]);
        if (conflict.length) {
            return res.redirect('/admin/appointments?error=That time slot is already booked for this doctor');
        }
        await db.query(
            'INSERT INTO appointment (doctor_id, patient_id, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?)',
            [doctor_id, patient_id, appointment_time, reason || null, 'Scheduled']);
        res.redirect('/admin/appointments?success=Appointment created successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/appointments?error=Failed to create appointment');
    }
});

router.post('/appointments/update/:id', async (req, res) => {
    const { status } = req.body;
    try {
        await db.query('UPDATE appointment SET status=? WHERE appointment_id=?', [status, req.params.id]);
        res.redirect('/admin/appointments?success=Status updated successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/appointments?error=Update failed');
    }
});

// ── Billing ────────────────────────────────────────────────────────────────────
router.get('/billing', async (req, res) => {
    try {
        const [bills] = await db.query(`
            SELECT b.*, u.full_name AS patient_name
            FROM billing b
            JOIN patient p ON b.patient_id = p.patient_id
            JOIN users u ON p.user_id = u.user_id
            ORDER BY b.bill_date DESC`);
        const [patients] = await db.query('SELECT p.patient_id, u.full_name FROM patient p JOIN users u ON p.user_id=u.user_id');
        const [[{ totalRevenue }]] = await db.query("SELECT COALESCE(SUM(total_amount),0) AS totalRevenue FROM billing WHERE payment_status='Paid'");
        const [[{ pendingAmount }]] = await db.query("SELECT COALESCE(SUM(total_amount),0) AS pendingAmount FROM billing WHERE payment_status='Pending'");
        res.render('admin/billing', {
            session: req.session,
            bills, patients,
            totalRevenue, pendingAmount,
            error: req.query.error || null,
            success: req.query.success || null
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error loading billing.' });
    }
});

router.post('/billing/add', async (req, res) => {
    const { patient_id, total_amount, description } = req.body;
    if (!patient_id || !total_amount) {
        return res.redirect('/admin/billing?error=Patient and amount are required');
    }
    try {
        await db.query('INSERT INTO billing (patient_id, bill_date, total_amount, description) VALUES (?, CURDATE(), ?, ?)',
            [patient_id, total_amount, description || null]);
        res.redirect('/admin/billing?success=Bill added successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/billing?error=Failed to add bill');
    }
});

router.post('/billing/update/:id', async (req, res) => {
    const { payment_status } = req.body;
    try {
        await db.query('UPDATE billing SET payment_status=? WHERE bill_id=?', [payment_status, req.params.id]);
        res.redirect('/admin/billing?success=Payment status updated');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/billing?error=Update failed');
    }
});

router.post('/billing/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM billing WHERE bill_id=?', [req.params.id]);
        res.redirect('/admin/billing?success=Bill deleted successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/billing?error=Delete failed');
    }
});

// ── Nurse Assignments ──────────────────────────────────────────────────────────
router.get('/nurse-assignments', async (req, res) => {
    try {
        const [assignments] = await db.query(`
            SELECT na.*, u_n.full_name AS nurse_name, u_p.full_name AS patient_name
            FROM nurse_assignment na
            JOIN nurse n ON na.nurse_id = n.nurse_id
            JOIN users u_n ON n.user_id = u_n.user_id
            JOIN patient p ON na.patient_id = p.patient_id
            JOIN users u_p ON p.user_id = u_p.user_id
            ORDER BY na.assigned_date DESC`);
        const [nurses]   = await db.query('SELECT n.nurse_id, u.full_name FROM nurse n JOIN users u ON n.user_id=u.user_id');
        const [patients] = await db.query('SELECT p.patient_id, u.full_name FROM patient p JOIN users u ON p.user_id=u.user_id');
        res.render('admin/nurse_assignments', {
            session: req.session,
            assignments, nurses, patients,
            error: req.query.error || null,
            success: req.query.success || null
        });
    } catch (err) {
        console.error(err);
        res.render('error', { message: 'Error loading nurse assignments.' });
    }
});

router.post('/nurse-assignments/add', async (req, res) => {
    const { nurse_id, patient_id, notes } = req.body;
    if (!nurse_id || !patient_id) {
        return res.redirect('/admin/nurse-assignments?error=Nurse and patient are required');
    }
    try {
        // Check duplicate assignment
        const [existing] = await db.query(
            'SELECT 1 FROM nurse_assignment WHERE nurse_id=? AND patient_id=?',
            [nurse_id, patient_id]);
        if (existing.length) {
            return res.redirect('/admin/nurse-assignments?error=This nurse is already assigned to this patient');
        }
        await db.query('INSERT INTO nurse_assignment (nurse_id, patient_id, assigned_date, notes) VALUES (?, ?, CURDATE(), ?)',
            [nurse_id, patient_id, notes || null]);
        res.redirect('/admin/nurse-assignments?success=Nurse assigned successfully');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/nurse-assignments?error=Failed to assign nurse');
    }
});

router.post('/nurse-assignments/delete/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM nurse_assignment WHERE assignment_id=?', [req.params.id]);
        res.redirect('/admin/nurse-assignments?success=Assignment removed');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/nurse-assignments?error=Remove failed');
    }
});

export default router;
