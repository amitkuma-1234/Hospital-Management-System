// routes/auth.js
import express from 'express';
import bcrypt from 'bcryptjs';
import db from '../db.js';

const router = express.Router();

router.get('/login', (req, res) => {
    if (req.session.userId) return res.redirect(`/${req.session.role}/dashboard`);
    res.render('login', { error: null });
});

router.post('/login', async (req, res) => {
    const { username, password, role } = req.body;
    if (!username || !password || !role) {
        return res.render('login', { error: 'All fields are required.' });
    }
    try {
        const [rows] = await db.query(
            'SELECT * FROM users WHERE username = ? AND role = ?',
            [username, role]
        );
        if (!rows.length) return res.render('login', { error: 'Invalid credentials.' });
        const user = rows[0];
        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.render('login', { error: 'Invalid credentials.' });
        req.session.userId   = user.user_id;
        req.session.username = user.username;
        req.session.fullName = user.full_name;
        req.session.role     = user.role;
        res.redirect(`/${user.role}/dashboard`);
    } catch (err) {
        console.error(err);
        res.render('login', { error: 'Server error. Please try again.' });
    }
});

router.get('/signup', (req, res) => res.render('signup', { error: null, success: null }));

router.post('/signup', async (req, res) => {
    const { username, full_name, email, password, confirm_password } = req.body;
    if (password !== confirm_password)
        return res.render('signup', { error: 'Passwords do not match.', success: null });
    if (password.length < 6)
        return res.render('signup', { error: 'Password must be at least 6 characters.', success: null });
    try {
        const hashed = await bcrypt.hash(password, 10);
        const [result] = await db.query(
            'INSERT INTO users (username, full_name, email, password, role) VALUES (?, ?, ?, ?, ?)',
            [username, full_name, email || null, hashed, 'patient']
        );
        // Create patient profile
        await db.query('INSERT INTO patient (user_id) VALUES (?)', [result.insertId]);
        res.render('signup', { error: null, success: 'Account created! You can now log in.' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.render('signup', { error: 'Username or email already exists.', success: null });
        console.error(err);
        res.render('signup', { error: 'Server error. Please try again.', success: null });
    }
});

router.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
});

export default router;
