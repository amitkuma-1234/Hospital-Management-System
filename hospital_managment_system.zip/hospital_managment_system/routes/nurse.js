// routes/nurse.js
import express from 'express';
import db from '../db.js';
import { requireRole } from '../middleware/auth.js';

const router = express.Router();
router.use(requireRole('nurse'));

async function getNurseId(userId) {
    const [[n]] = await db.query('SELECT nurse_id FROM nurse WHERE user_id=?', [userId]);
    return n?.nurse_id;
}

router.get('/dashboard', async (req, res) => {
    try {
        const nurseId = await getNurseId(req.session.userId);
        const [[{ assignedPatients }]] = await db.query(
            'SELECT COUNT(*) AS assignedPatients FROM nurse_assignment WHERE nurse_id=?', [nurseId]);
        const [[{ todayAppts }]] = await db.query(
            "SELECT COUNT(*) AS todayAppts FROM appointment WHERE DATE(appointment_time)=CURDATE()");
        const [assignments] = await db.query(`
            SELECT na.*, u.full_name AS patient_name
            FROM nurse_assignment na
            JOIN patient p ON na.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE na.nurse_id=?`, [nurseId]);
        res.render('nurse/dashboard', { session: req.session, stats: { assignedPatients, todayAppts }, assignments });
    } catch (err) {
        res.render('error', { message: 'Error loading dashboard.' });
    }
});

router.get('/patients', async (req, res) => {
    try {
        const nurseId = await getNurseId(req.session.userId);
        const [patients] = await db.query(`
            SELECT p.*, u.full_name, na.notes, na.assignment_id
            FROM nurse_assignment na
            JOIN patient p ON na.patient_id=p.patient_id
            JOIN users u ON p.user_id=u.user_id
            WHERE na.nurse_id=?`, [nurseId]);
        res.render('nurse/patients', { session: req.session, patients, error: req.query.error, success: req.query.success });
    } catch (err) {
        res.render('error', { message: 'Error loading patients.' });
    }
});

router.post('/assignments/update/:id', async (req, res) => {
    const { notes } = req.body;
    try {
        await db.query('UPDATE nurse_assignment SET notes=? WHERE assignment_id=?', [notes, req.params.id]);
        res.redirect('/nurse/patients?success=Notes updated');
    } catch (err) {
        res.redirect('/nurse/patients?error=Update failed');
    }
});

router.get('/appointments', async (req, res) => {
    try {
        const [appointments] = await db.query(`
            SELECT a.*, u_d.full_name AS doctor_name, u_p.full_name AS patient_name
            FROM appointment a
            JOIN doctor d ON a.doctor_id=d.doctor_id
            JOIN users u_d ON d.user_id=u_d.user_id
            JOIN patient p ON a.patient_id=p.patient_id
            JOIN users u_p ON p.user_id=u_p.user_id
            ORDER BY a.appointment_time DESC`);
        res.render('nurse/appointments', { session: req.session, appointments });
    } catch (err) {
        res.render('error', { message: 'Error loading appointments.' });
    }
});

router.get('/medical-records', async (req, res) => {
    try {
        const [records] = await db.query(`
            SELECT mr.*, u_p.full_name AS patient_name, u_d.full_name AS doctor_name
            FROM medical_record mr
            JOIN patient p ON mr.patient_id=p.patient_id
            JOIN users u_p ON p.user_id=u_p.user_id
            JOIN doctor d ON mr.doctor_id=d.doctor_id
            JOIN users u_d ON d.user_id=u_d.user_id
            ORDER BY mr.date_created DESC`);
        res.render('nurse/medical_records', { session: req.session, records });
    } catch (err) {
        res.render('error', { message: 'Error loading records.' });
    }
});

export default router;
