// Quick script to generate the correct bcrypt hash for "password123"
import bcrypt from 'bcryptjs';
const hash = await bcrypt.hash('password123', 10);
console.log('Hash for password123:', hash);

// Verify it works
const match = await bcrypt.compare('password123', hash);
console.log('Verification:', match ? '✅ PASS' : '❌ FAIL');
